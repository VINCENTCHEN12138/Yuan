# encoding: utf-8
from django.apps import AppConfig


class Zhouxinyuan11Config(AppConfig):
    name = 'zhouxinyuan11'
