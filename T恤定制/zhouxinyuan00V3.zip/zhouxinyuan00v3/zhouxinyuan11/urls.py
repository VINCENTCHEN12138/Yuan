# encoding: utf-8
from django.conf.urls import url
from zhouxinyuan11 import views_if


urlpatterns = [

     #url(r'^api/add_Orders/', views_if.add_Orders, name='add_Orders'),
     #url(r'^api/get_Orders/', views_if.get_Orders, name='get_Orders'),


]